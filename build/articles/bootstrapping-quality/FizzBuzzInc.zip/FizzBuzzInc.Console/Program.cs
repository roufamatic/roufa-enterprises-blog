﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FizzBuzzInc.Services;
using ThirdParty.Twitter;

namespace FizzBuzzInc.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            var twit = new Twit();
            // UI Code here!
            var fbService = new FizzBuzzService(twit);
            for (var i = 1; i <= 100; i++)
            {
                System.Console.WriteLine("{0}. {1}", i, fbService.Fetch(i));
            }

                System.Console.WriteLine("Press any key...");
            System.Console.ReadKey();


        }
    }
}
