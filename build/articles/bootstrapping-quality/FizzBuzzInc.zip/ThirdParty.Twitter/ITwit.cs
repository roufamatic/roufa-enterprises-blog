﻿namespace ThirdParty.Twitter
{
    public interface ITwit
    {
        string GetLatestTweet();
    }
}