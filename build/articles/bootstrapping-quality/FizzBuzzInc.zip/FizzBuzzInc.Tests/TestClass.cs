﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FizzBuzzInc.Services;
using Moq;
using NUnit.Framework;
using ThirdParty.Twitter;

namespace FizzBuzzInc.Tests
{
    [TestFixture]
    public class TestClass
    {
        private FizzBuzzService _fizzBuzzService;
        [SetUp]
        public void Setup()
        {
            var myMock = new Mock<ITwit>();
            myMock.Setup(twit => twit.GetLatestTweet()).Returns("testytest");
            _fizzBuzzService = new FizzBuzzService(myMock.Object);
        }

        [Test]
        public void SanityCheck()
        {
            Assert.AreEqual(1,1);
        }

        [Test]
        public void TheServiceFizzesOnThrees()
        {
            for (var i = 3; i <= 100; i += 3)
            {
                if (i%5 == 0) continue;
                Assert.AreEqual("fizz", _fizzBuzzService.Fetch(i));
            }
        }

        [Test]
        public void TheServiceBuzzesOnFives()
        {
            for (var i = 5; i <= 100; i += 5)
            {
                if (i%3 == 0) continue;
                Assert.AreEqual("buzz", _fizzBuzzService.Fetch(i));
            }
        }
        
        [Test]
        public void TheServiceFizzBuzzesOnFifteen()
        {
            for (var i = 15; i <= 100; i += 15)
            {
                Assert.AreEqual("fizzbuzz", _fizzBuzzService.Fetch(i));
            }
        }
        
        [Test]
        public void TheServiceTweetsOnNinetyEight()
        {
            Assert.AreEqual("testytest", _fizzBuzzService.Fetch(98));
        }

    }
}
