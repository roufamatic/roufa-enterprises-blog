﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdParty.Twitter;

namespace FizzBuzzInc.Services
{
    public class FizzBuzzService
    {
        private readonly ITwit _twit;

        public FizzBuzzService(ITwit twit)
        {
            _twit = twit;
        }

        public string Fetch(int i)
        {
            if (i == 98) return _twit.GetLatestTweet();
            var output = "";

            if (i%3 == 0) output += "fizz";
            if (i%5 == 0) output += "buzz";
            return output;
        }
    }
}
